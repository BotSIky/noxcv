const express = require('express');
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const settings = require("./settings.json")

const app = express();
const PORT = process.env.PORT || 4000;

app.enable("trust proxy");
app.set("json spaces", 2);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use('/', express.static(path.join(__dirname, 'src')));

app.use((req, res, next) => {
    const originalJson = res.json;
    res.json = function (data) {
        if (data && typeof data === 'object') {
            const responseData = {
                status: data.status,
                creator: settings.apiSettings.creator || "Dibuat oleh Tanaka Sensei",
                ...data
            };
            return originalJson.call(this, responseData);
        }
        return originalJson.call(this, data);
    };
    next();
});

// Api Route
let totalRoutes = 0;
const apiFolder = path.join(__dirname, './api');
fs.readdirSync(apiFolder).forEach((subfolder) => {
    const subfolderPath = path.join(apiFolder, subfolder);
    if (fs.statSync(subfolderPath).isDirectory()) {
        fs.readdirSync(subfolderPath).forEach((file) => {
            const filePath = path.join(subfolderPath, file);
            if (path.extname(file) === '.js') {
                require(filePath)(app);
                totalRoutes++;
                console.log(` Loaded Route: ${path.basename(file)} `)
            }
        });
    }
});
console.log(' Load Complete! ✓ ')
console.log(` Total Routes Loaded: ${totalRoutes} `)

app.get('/', (req, res) =>
  res.render('index', { settings })
);

app.use((req, res, next) => {
    res.status(404)
    res.render('404')
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500)
    res.render('500')
});

app.listen(PORT, () => {
    console.log(` Server is running on port ${PORT} `)
});

module.exports = app;
