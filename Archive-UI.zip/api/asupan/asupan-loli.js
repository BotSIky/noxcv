const axios = require('axios');

module.exports = function(app) {
    app.get('/asupan/loli', async (req, res) => {
        try {
            let buffer = await (await axios.get("https://www.loliapi.com/acg/pe/", { responseType: 'arraybuffer' }));
            res.set('Content-Type', 'image/png');
            res.send(buffer.data);
        } catch (error) {
            res.status(500).json({ status: false, error: error.message });
        }
    });
};