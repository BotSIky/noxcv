const axios = require('axios');
const cheerio = require('cheerio');
module.exports = function(app) {
    async function spotifyDL(url) {
        return new Promise(async (resolve, reject) => {
            try {
                const metadata = await axios.get(
                    `https://api.fabdl.com/spotify/get?url=${encodeURIComponent(url)}`, {
                        headers: {
                            accept: "application/json, text/plain, */*",
                            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                            "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
                            "sec-ch-ua-mobile": "?1",
                            "sec-ch-ua-platform": "\"Android\"",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "cross-site",
                            Referer: "https://spotifydownload.org/",
                            "Referrer-Policy": "strict-origin-when-cross-origin",
                        },
                    }
                );
                const lilydata = await axios.get(
                    `https://api.fabdl.com/spotify/mp3-convert-task/${metadata.data.result.gid}/${metadata.data.result.id}`, {
                        headers: {
                            accept: "application/json, text/plain, */*",
                            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                            "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
                            "sec-ch-ua-mobile": "?1",
                            "sec-ch-ua-platform": "\"Android\"",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "cross-site",
                            Referer: "https://spotifydownload.org/",
                            "Referrer-Policy": "strict-origin-when-cross-origin",
                        },
                    }
                );
                const data = {};
                data.title = metadata.data.result.name;
                data.type = metadata.data.result.type;
                data.artis = metadata.data.result.artists;
                data.durasi = metadata.data.result.duration_ms;
                data.image = metadata.data.result.image;
                data.download = "https://api.fabdl.com" + lilydata.data.result.download_url;
                resolve({
                    data
                });
            } catch (error) {
                reject(error);
            }
        });
    };
    app.get('/download/spotify', async (req, res) => {
        try {
            const {
                url
            } = req.query;
            if (!url) {
                return res.status(400).json({
                    status: false,
                    error: 'URL is required'
                });
            }
            const result = await spotifyDL(url);
            res.status(200).json({
                status: true,
                result
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};