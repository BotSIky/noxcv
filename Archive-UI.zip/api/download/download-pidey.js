const axios = require('axios');
const cheerio = require('cheerio');
module.exports = function(app) {
    async function pideyDL(url) {
        try {
            const {
                data: metadata
            } = await axios.get(url);
            const $ = cheerio.load(metadata);
            const videos = $("source[type='video/mp4']").attr("src");

            if (videos) {
                return {
                    dowmloads: "https://pidey.co" + videos.replace(".", "")
                }
            } else {
                return {
                    err: true,
                    msg: "Tidak Ada Urls Dowmload"
                }
            }
        } catch (error) {
            console.error(`Error saat scraping: ${error.message}`);
        }
    }
    app.get('/download/pidey', async (req, res) => {
        try {
            const {
                url
            } = req.query;
            if (!url) {
                return res.status(400).json({
                    status: false,
                    error: 'URL is required'
                });
            }
            const result = await pideyDL(url);
            res.status(200).json({
                status: true,
                result
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};