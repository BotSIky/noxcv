const axios = require('axios');
const cheerio = require('cheerio');
const fetch = require("node-fetch");
module.exports = function(app) {
    async function scraperSnackVideoDL(url) {
        const res = await fetch(url);
        const body = await res.text();
        const $ = cheerio.load(body);
        const video = $("div.video-box").find("a-video-player");
        const author = $("div.author-info");
        const attr = $("div.action");

        const results = {
            title: $(author).find("div.author-desc > span").children("span").eq(0).text().trim(),
            thumbnail: $(video).parent().siblings("div.background-mask").children("img").attr("src"),
            media: $(video).attr("src"),
            author: $("div.author-name").text().trim(),
            authorImage: $(attr).find("div.avatar > img").attr("src"),
            like: $(attr).find("div.common").eq(0).text().trim(),
            comment: $(attr).find("div.common").eq(1).text().trim(),
            share: $(attr).find("div.common").eq(2).text().trim(),
        };

        return results;
    }
    app.get('/download/snackvideo', async (req, res) => {
        try {
            const {
                url
            } = req.query;
            if (!url) {
                return res.status(400).json({
                    status: false,
                    error: 'URL is required'
                });
            }
            const result = await scraperSnackVideoDL(url);
            res.status(200).json({
                status: true,
                result
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};