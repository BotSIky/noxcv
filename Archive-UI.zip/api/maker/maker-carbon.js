const axios = require('axios');
const FormData = require('form-data');
module.exports = function(app) {
    async function carbon(code) {
        const formData = new FormData();
        formData.append('code', code);
        formData.append('backgroundColor', '#1F816D');

        let result = await axios.post('https://carbonara.solopov.dev/api/cook', formData, {
            headers: formData.getHeaders(),
            responseType: 'arraybuffer'
        });

        return result.data;
    }
    app.get('/maker/carbon', async (req, res) => {
        try {
            const {
                text
            } = req.query;
            if (!text) {
                return res.status(400).json({
                    status: false,
                    error: 'Prompt is required'
                });
            }
            let buffer = await carbon(text)
            res.set('Content-Type', 'image/png');
            res.send(buffer);
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};