const axios = require('axios');
const fetch = require("node-fetch");
module.exports = function(app) {
    async function generateImage(prompt) {
        const data = {
            captionInput: prompt,
            captionModel: "default"
        };

        const url = 'https://chat-gpt.pictures/api/generateImage';

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();
            return result;
        } catch (error) {
            console.error("Error:", error);
            throw error;
        }
    }
    app.get('/ai/bingimg', async (req, res) => {
        try {
            const {
                text
            } = req.query;
            if (!text) {
                return res.status(400).json({
                    status: false,
                    error: 'Prompt is required'
                });
            }
            const {
                result
            } = await generateImage(text);
            res.status(200).json({
                status: true,
                result
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};