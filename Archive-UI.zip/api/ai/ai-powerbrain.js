const axios = require('axios');
module.exports = function(app) {
    async function powerbrain(question) {
        const data = `message=${encodeURIComponent(question)}&messageCount=1`

        const config = {
            method: 'POST',
            url: 'https://powerbrainai.com/chat.php',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
                'Content-Type': 'application/x-www-form-urlencoded',
                'accept-language': 'id-ID',
                'referer': 'https://powerbrainai.com/chat.html',
                'origin': 'https://powerbrainai.com',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'priority': 'u=0',
                'te': 'trailers'
            },
            data: data
        }
        const api = await axios.request(config)
        return { 
        results: api.data.response               
       }
    }
    app.get('/ai/powerbrain', async (req, res) => {
        try {
            const {
                text
            } = req.query;
            if (!text) {
                return res.status(400).json({
                    status: false,
                    error: 'Text is required'
                });
            }
            const {
                result
            } = await powerbrain(text);
            res.status(200).json({
                status: true,
                result
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};