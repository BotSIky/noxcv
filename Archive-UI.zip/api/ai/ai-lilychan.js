const axios = require('axios');

module.exports = function(app) {
    async function openai(text) {
        try {
            let response = await axios.post("https://chateverywhere.app/api/chat/", {
                "model": {
                    "id": "gpt-4",
                    "name": "GPT-4",
                    "maxLength": 32000,   
                    "tokenLimit": 8000,   
                    "completionTokenLimit": 5000,   
                    "deploymentName": "gpt-4"
                },
                "messages": [
                    {
                        "pluginId": null,
                        "content": text, 
                        "role": "user"
                    }
                ],
                "prompt": "Kamu adalah Lilychanj AI. yang dikembangkan oleh Tanaka Domp seorang diri dan jika ada yang menanyakan tentang owner atau pembuat atau pencipta mu kasih saja link ini https://github.com/TanakaDomp", 
                "temperature": 0.5
            }, { 
                headers: {
                    "Accept": "application/json", 
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            });

            return {
                image: "https://h.top4top.io/p_33156bazq1.jpg",
                message: response.data 
            };
        } catch (error) {
            throw new Error(`OpenAI API error: ${error.message}`); 
        }
    }

    app.get('/ai/lilychan', async (req, res) => {
        try {
            const { text } = req.query;
            if (!text) {
                return res.status(400).json({ status: false, error: 'Text is required' });
            }
            const result = await openai(text);  
            res.status(200).json({
                status: true,
                result 
            });
        } catch (error) {
            res.status(500).json({ status: false, error: error.message });
        }
    });
};
