const axios = require('axios');
const cheerio = require('cheerio');
const fetch = require("node-fetch");
module.exports = function(app) {
    async function snackSearch(query) {
        const url = 'https://www.snackvideo.com/rest/o/w/pwa/discover';
        const headers = {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K)",
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://www.snackvideo.com/discover/"
        };

        const body = JSON.stringify({
            searchWord: query,
            pcursor: '0',
            fromUser: false,
            mobile: true,
            request_source: 1102,
            seoDefaultFilterV2: true,
            count: 30
        });

        const response = await fetch(url, {
            method: 'POST',
            headers,
            body
        });

        if (response.ok) {
            const data = await response.json();
            const processedData = data.feeds.map(feed => ({
                caption: feed.caption || 'Tidak ada caption',
                like_count: feed.like_count || 'Tidak ada like',
                view_count: feed.view_count || 'Tidak ada view',
                comment_count: feed.comment_count || 'Tidak ada komentar',
                forward_count: feed.forward_count || 'Tidak ada forward',
                kwai_id: feed.kwai_id,
                timestamp: feed.timestamp,
                photo_id_str: feed.photo_id_str,
                url: `https://www.snackvideo.com/@${feed.kwai_id}/video/${feed.photo_id_str}`
            }));

            const randomResult = processedData[Math.floor(Math.random() * processedData.length)];
            const results = {
                title: randomResult.caption,
                like: randomResult.like_count,
                comments: randomResult.comment_count,
                share: randomResult.forward_count,
                URL: randomResult.url
            };

            return results;
        } else {
            return response.statusText;
        }
    }


    app.get('/search/snackvideo', async (req, res) => {
        try {
            const {
                q
            } = req.query;
            if (!q) {
                return res.status(400).json({
                    status: false,
                    error: 'Query is required'
                });
            }
            const result = await snackSearch(q);
            res.status(200).json({
                status: true,
                result
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};
