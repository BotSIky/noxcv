const axios = require('axios');
const cheerio = require('cheerio');
const fetch = require("node-fetch");
module.exports = function(app) {
    async function xnxxSearch(t) {
        return new Promise((n, e) => {
            const r = "https://www.xnxx.com";
            fetch(`${r}/search/${t}/${Math.floor(3 * Math.random()) + 1}`, {
                    method: "get",
                })
                .then((t) => t.text())
                .then((t) => {
                    let e = cheerio.load(t, {
                            xmlMode: !1
                        }),
                        o = [],
                        a = [],
                        i = [],
                        s = [];
                    e("div.mozaique").each(function(t, n) {
                            e(n)
                                .find("div.thumb")
                                .each(function(t, n) {
                                    a.push(
                                        r + e(n).find("a").attr("href").replace("/THUMBNUM/", "/")
                                    );
                                });
                        }),
                        e("div.mozaique").each(function(t, n) {
                            e(n)
                                .find("div.thumb-under")
                                .each(function(t, n) {
                                    i.push(e(n).find("p.metadata").text()),
                                        e(n)
                                        .find("a")
                                        .each(function(t, n) {
                                            o.push(e(n).attr("title"));
                                        });
                                });
                        });
                    for (let t = 0; t < o.length; t++)
                        s.push({
                            title: o[t],
                            info: i[t],
                            link: a[t]
                        });
                    n(
                      s
                    );
                })
                .catch((t) => e(
                    t));
        });
    }
    app.get('/search/xnxx', async (req, res) => {
        try {
            const {
                q
            } = req.query;
            if (!q) {
                return res.status(400).json({
                    status: false,
                    error: 'Query is required'
                });
            }
            const result = await xnxxSearch(q);
            res.status(200).json({
                status: true,
                result
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};