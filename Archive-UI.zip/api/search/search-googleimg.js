const axios = require('axios');
const cheerio = require('cheerio');
module.exports = function(app) {
    async function googleImg(query) {
        try {
            const {
                data: html
            } = await axios.get(`https://www.google.com/search?q=${query}&sclient=mobile-gws-wiz-img&udm=2`);
            const $ = cheerio.load(html);

            const imageUrls = [];
            $('img.DS1iW').each((i, el) => {
                const imgUrl = $(el).attr('src');
                if (imgUrl) imageUrls.push(imgUrl);
            });

            return imageUrls;
        } catch (error) {
            console.error('Error fetching images:', error);
            return [];
        }
    }
    app.get('/search/googleimg', async (req, res) => {
        try {
            const {
                q
            } = req.query;
            if (!q) {
                return res.status(400).json({
                    status: false,
                    error: 'Query is required'
                });
            }
            const result = await googleImg(q);
            res.status(200).json({
                status: true,
                result
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};