const axios = require('axios');
const cheerio = require('cheerio');
module.exports = function(app) {
    async function fontsearch(teks) {
        try {
            const {
                data
            } = await axios.get('https://font.download/search?q=' + teks);
            const $ = cheerio.load(data);
            const fonts = [];

            $('#font-list .font-list-item').each((index, element) => {
                const title = $(element).find('.title h5 a').text().trim();
                const addedBy = $(element).find('.title p').text().trim();
                const downloadLink = $(element).find('.buttons a').attr('href');
                const imageUrl = $(element).find('.image img').attr('src');

                fonts.push({
                    title,
                    addedBy,
                    downloadLink,
                    imageUrl
                });
            });

            return fonts

        } catch (error) {
            return error.message;
        }
    }
    app.get('/search/font', async (req, res) => {
        try {
            const {
                q
            } = req.query;
            if (!q) {
                return res.status(400).json({
                    status: false,
                    error: 'Query is required'
                });
            }
            const result = await fontsearch(q);
            res.status(200).json({
                status: true,
                result
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};