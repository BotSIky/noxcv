document.addEventListener('DOMContentLoaded', async () => {
    try {
        document.getElementById("url").textContent = `[ ${window.location.origin} ]`;

        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', () => {
            const searchTerm = searchInput.value.toLowerCase();
            const apiItems = document.querySelectorAll('.api-item');
            const categoryHeaders = document.querySelectorAll('.category-header');

            apiItems.forEach(item => {
                const name = item.getAttribute('data-name').toLowerCase();
                const desc = item.getAttribute('data-desc').toLowerCase();
                item.style.display = (name.includes(searchTerm) || desc.includes(searchTerm)) ? '' : 'none';
            });

            categoryHeaders.forEach(header => {
                const categoryRow = header.nextElementSibling;
                if (!categoryRow) return;
                const visibleItems = categoryRow.querySelectorAll('.api-item');
                const hasVisibleItems = Array.from(visibleItems).some(item => item.style.display !== 'none');
                header.style.display = hasVisibleItems ? '' : 'none';
            });
        });

        document.addEventListener('click', event => {
            if (!event.target.classList.contains('get-api-btn')) return;

            const { apiPath, apiName, apiDesc } = event.target.dataset;
            const modal = new bootstrap.Modal(document.getElementById('apiResponseModal'));
            const modalRefs = {
                label: document.getElementById('apiResponseModalLabel'),
                desc: document.getElementById('apiResponseModalDesc'),
                content: document.getElementById('apiResponseContent'),
                endpoint: document.getElementById('apiEndpoint'),
                spinner: document.getElementById('apiResponseLoading'),
                queryInputContainer: document.getElementById('apiQueryInputContainer'),
                submitBtn: document.getElementById('submitQueryBtn')
            };

            modalRefs.label.textContent = apiName;
            modalRefs.desc.textContent = apiDesc;
            modalRefs.content.textContent = '';
            modalRefs.endpoint.textContent = '';
            modalRefs.spinner.classList.add('d-none');
            modalRefs.content.classList.add('d-none');
            modalRefs.endpoint.classList.add('d-none');

            const hasQuery = apiPath.includes('?');
            if (!hasQuery) {
                modalRefs.spinner.classList.remove('d-none');
                modalRefs.content.classList.add('d-none');
                modalRefs.submitBtn.classList.add('d-none');
                modalRefs.queryInputContainer.innerHTML = '';             
                const apiUrl = `${window.location.origin}${apiPath}`;
                fetchAndDisplayMedia(apiUrl, modalRefs);
            } else {
                const queryPlaceholder = new URLSearchParams(apiPath.split('?')[1]).keys().next().value || 'query';
                const inputField = Object.assign(document.createElement('input'), {
                    type: 'text',
                    className: 'form-control',
                    placeholder: `Enter ${queryPlaceholder}...`
                });

                modalRefs.queryInputContainer.replaceChildren(inputField);

                modalRefs.submitBtn.classList.remove('d-none');
                modalRefs.submitBtn.onclick = async () => {
                    const query = inputField.value;
                    if (!query && apiPath.includes('?')) {
                        modalRefs.content.textContent = 'Please enter a query.';
                        modalRefs.content.classList.remove('d-none');
                        return;
                    }

                    modalRefs.spinner.classList.remove('d-none');
                    modalRefs.content.classList.add('d-none');
                    modalRefs.submitBtn.classList.add('d-none');
                    modalRefs.queryInputContainer.innerHTML = '';

                    try {
                        const apiUrl = query ? `${window.location.origin}${apiPath}?query=${encodeURIComponent(query)}` : `${window.location.origin}${apiPath}`;
                        await fetchAndDisplayMedia(apiUrl, modalRefs);
                    } catch (error) {
                        modalRefs.content.textContent = `Error: ${error.message}`;
                    } finally {
                        modalRefs.spinner.classList.add('d-none');
                        modalRefs.content.classList.remove('d-none');
                    }
                }
            }

            modal.show();
        });
    } catch (error) {
        console.error('Error: ', error);
    }
});

window.addEventListener('scroll', function () {
    const navbar = document.querySelector('.navbar');
    const navbarBrand = document.querySelector('.navbar-brand');
    if (window.scrollY > 0) {
        navbarBrand.classList.add('visible');
        navbar.classList.add('scrolled');
    } else {
        navbarBrand.classList.remove('visible');
        navbar.classList.remove('scrolled');
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const loadingScreen = document.getElementById("loadingScreen");
    const body = document.body;
    body.classList.add("no-scroll");
    setTimeout(() => {
        loadingScreen.style.display = "none";
        body.classList.remove("no-scroll");
    }, 2000);
});

async function fetchAndDisplayMedia(apiUrl, modalRefs) {
    try {
        const response = await fetch(apiUrl);
        const contentType = response.headers.get("Content-Type");

        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }
      
        if (contentType.includes("image/")) {
            const blob = await response.blob();
            const imgUrl = URL.createObjectURL(blob);
            modalRefs.content.innerHTML = `<img src="${imgUrl}" alt="Image Result" style="max-width: 100%;">`;
        } else if (contentType.includes("video/")) {
            const blob = await response.blob();
            const videoUrl = URL.createObjectURL(blob);
            modalRefs.content.innerHTML = `<video controls style="max-width: 100%;"><source src="${videoUrl}" type="${contentType}"></video>`;
        } else if (contentType.includes("audio/")) {
            const blob = await response.blob();
            const audioUrl = URL.createObjectURL(blob);
            modalRefs.content.innerHTML = `<audio controls style="width: 100%;"><source src="${audioUrl}" type="${contentType}"></audio>`;
        } else if (contentType.includes("application/json")) {
            const data = await response.json();
            modalRefs.content.textContent = JSON.stringify(data, null, 2); 
        } else {
            modalRefs.content.textContent = `Unknown content type: ${contentType}`;
        }

        modalRefs.endpoint.textContent = apiUrl;
        modalRefs.endpoint.classList.remove('d-none');
        modalRefs.spinner.classList.add('d-none');
        modalRefs.content.classList.remove('d-none');
    } catch (error) {
        modalRefs.content.textContent = `Error: ${error.message}`;
        modalRefs.spinner.classList.add('d-none');
        modalRefs.content.classList.remove('d-none');
    }
}